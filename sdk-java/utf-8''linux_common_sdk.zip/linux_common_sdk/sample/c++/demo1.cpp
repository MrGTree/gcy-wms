#include <iostream>
#include <fstream>
#include <unistd.h>
#include <chrono>
#include <vector>
#include "sensight_common.h"
#include "sensight_face.h"
#include "sensight_feature.h"
#include "sensight_image.h"
#include "sensight_attribute.h"
#include "sensight_align.h"
#include "sensight_license.h"
#include "sensight_liveness.h"
#include "opencv2/opencv.hpp"

using namespace std;

STResult face();
STResult attribute();

std::chrono::milliseconds faceSUM;
std::chrono::milliseconds featureSUM;
std::chrono::milliseconds attrSUM;
std::chrono::milliseconds liveSUM;


int liveCount=0;

struct Model {
	const char* faceDetectModel = "../../models/M_Detect_Hunter_Common_Gray_10.1.1.model";
	const char* faceAlignModel = "../../models/M_Align_Deepface_106_track_2.20.1.model";
	const char* headPoseModel = "../../models/M_Align_CalcPose_Ann_106_2.3.0.model";

	const char* attributeModel = "../../models/M_Attribute_Face_Advertisement_2.11.1_2.11.1.model";
	const char* featureModel = "../../models/M_Verify_Insight_Common_4.1.2.model";

	const char* livenessModel = "../../models/M_Liveness_Antispoofing_General_7.84.0.model";
};

const Model model;

const int times = 500;
string licensePath = "../../models/license.lic";

string srcImageFile = "../../test.jpg";
string srcImageFile1 = "../../test1.jpg";
string srcImageFile2 = "../../test.jpg";

string outImageFile = "../../cropImage.jpg";

STModel stmodelattr;
STModel stmodelalig;
STModel stmodelfeature;

STModel stmodellive;

STHandle faceTrackerHandle;
STHandle aligHandle;
STHandle attrHandle;
STHandle extractHandle;
STHandle compareHandle;

STHandle liveHandle;

STBuffer licenseBuffer;
STBuffer* codeBuffer;
STFace* faceArray;
int faceCount;
STImage image;
cv::Mat srcImage;
vector<STFeature> v;
const float SCORE = 0.6;
const float faceSCORE = 0.5;

int femaleSUM = 0;
int maleSUM = 0;


const int delay = 30;

int deviceId = 0;


bool flag = true;

void getImage(string srcImageFile) {


	srcImage = cv::imread(srcImageFile, -1);
	image.data = srcImage.data;

	image.format = ST_PIX_FMT_BGR888;
	image.width = srcImage.cols;
	image.height = srcImage.rows;
	image.stride = srcImage.step;// step;

}

void getImage(string srcImageFile, cv::Mat& srcImage, STImage* image) {
	srcImage = cv::imread(srcImageFile, -1);

	image->data = srcImage.data;

	image->format = ST_PIX_FMT_BGR888;
	image->width = srcImage.cols;
	image->height = srcImage.rows;
	image->stride = srcImage.step;// step;

}

void video() {
	cv::Mat frame;
	cv::VideoCapture cap;

	int apiID = cv::CAP_ANY;
	cap.set(cv::CAP_PROP_FORMAT, CV_8UC3);

	cap.open(deviceId+apiID);

	if (!cap.isOpened()) {
		cout << "error : open video failed." << endl;
		return;
	}
	cout << "Start grabbing." << endl;


	while (true) {
		cap.read(frame);
		if (frame.empty()) {
			cout << "error: blank frame grabbed." << endl;
			return;
		}

		image.data = frame.data;
		image.format = ST_PIX_FMT_BGR888;
		image.width = frame.cols;
		image.height = frame.rows;
		image.stride = frame.step;

		STResult r = ST_OK;

		if (ST_OK == stFaceTrackerTrack(faceTrackerHandle, &image, ST_FACE_UP, &faceArray, &faceCount) && faceCount > 0) {
			cout << "faces count:" << faceCount << endl;

			for (int i = 0; i < faceCount; i++) {
				if ((faceArray + i)->score < faceSCORE)
					continue;

				cout << "faceId:" << (faceArray + i)->id << endl;
				STAttribute attr;
				stFaceAttributeDetect(&image, faceArray + i, attrHandle, aligHandle, &attr);
				cout << "age:" << attr.age << "	gender:" << attr.gender << endl;
				cout <<"smile:" << attr.smile << " attractive:"<<attr.attractive<<endl;
				cout <<"mask:" << attr.mask << " glass:"<<attr.glass<<endl;
				cout <<"eye:" << attr.eye << " mouth:"<<attr.mouth<<endl;
				cout << "baby:" << attr.baby << " babycry:" << attr.babycry << endl;
				cout << "race:" << attr.race << " emotion:" << attr.emotion << endl;
				cout << "beard:" << attr.beard << endl;

				float fakeScore=0.0;

				std::chrono::milliseconds start = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
				if (ST_OK !=( r=stFaceLivenessVerify(&image, faceArray + i, liveHandle, aligHandle, &fakeScore))) {
					cout << "live verify failed. err code:"<<r << endl;
				}
				std::chrono::milliseconds end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
				liveSUM+=end-start;
				liveCount++;

				cout << "fake face score:" << fakeScore << endl;



				STFeature sf;
				if (ST_OK == stFeatureExtract(&image, faceArray + i, extractHandle, aligHandle, &sf)) {
					if (v.empty()) {
						v.push_back(sf);
						if (attr.gender == 0) {
							femaleSUM++;
						}
						else if (attr.gender == 1) {
							maleSUM++;
						}
					}
					for (auto a = v.cbegin(), b = v.cend(); a != b; ) {
						float score = 0.0;
						if (ST_OK == stFeatureCompare(compareHandle, sf, *a, &score) && score >= SCORE) {

							break;
						}
						++a;
						if (a == b) {
							v.push_back(sf);
							if (attr.gender == 0) {
								femaleSUM++;
							}
							else if (attr.gender == 1) {
								maleSUM++;
							}
						}

					}

				}

			}
			cout << endl;
			cout << "people count:" << v.size() << endl;
			cout << "female:" << femaleSUM << "	male:" << maleSUM << endl;
		}

		if (cv::waitKey(delay) >= 0)
			break;
	}

	cap.release();
}

STResult activation() {


	ifstream is(licensePath, ios::binary | ios::ate);
	if (!is) {
		cout << "open license failed." << endl;
		return -100;
	}

	licenseBuffer.size = is.tellg();
	licenseBuffer.data = malloc(licenseBuffer.size);
	is.seekg(0, ios::beg);
	is.read((char*)licenseBuffer.data, licenseBuffer.size);
	is.close();

	STResult r = ST_OK;

	if (ST_OK != (r = stGenerateActivationCode(&licenseBuffer, &codeBuffer))) {
		cout << "generateActivationCode failed.err code:" << r << endl;
	}
	else if (ST_OK != (r = stCheckActivationCode(&licenseBuffer, codeBuffer))) {
		cout << "checkActivationCode failed.err code:" << r << endl;
	}

	free(licenseBuffer.data);

	return r;
}

STResult loadModel() {
	STResult r;

	if (ST_OK != (r = stCommonLoadModel(model.attributeModel, &stmodelattr))) {
		cout << "load attribute Model failed." << endl;
		return r;
	}


	if (ST_OK != (r = stCommonLoadModel(model.faceAlignModel, &stmodelalig))) {
		cout << "load align model failed. err code:" << r << endl;
		return r;
	}


	if (ST_OK != (r = stCommonLoadModel(model.featureModel, &stmodelfeature))) {
		cout << "load feature model failed. err code:" << r << endl;
		return r;
	}

	if (ST_OK != (r = stCommonLoadModel(model.livenessModel, &stmodellive))) {
		cout << "load live model failed. err code:" << r << endl;
		return r;
	}


	return ST_OK;
}

void unloadModel() {
	stCommonUnloadModel(stmodelalig);
	stCommonUnloadModel(stmodelattr);
	stCommonUnloadModel(stmodelfeature);
	stCommonUnloadModel(stmodellive);
}

STResult loadFaceModel() {

	STResult r;
	if (ST_OK == (r = stFaceTrackerCreate(model.faceDetectModel, model.faceAlignModel, model.headPoseModel, &faceTrackerHandle))) {
		cout << "load faceDetectModel && faceAlignMode && headPoseModel success." << endl;
	}
	else {
		cout << "load faceDetectModel || faceAlignMode || headPoseModel failed.err code:" << r << endl;
		return r;
	}
	return ST_OK;
}

STResult faceTracker() {
	STResult r;

	STFaceDirection direction = ST_FACE_UP;

	for (int i = 0; i < times; ++i) {
		stFaceTrackerTrack(faceTrackerHandle, &image, direction, &faceArray, &faceCount);

		usleep(30);

	}


cout<<"begin track----"<<endl;

	std::chrono::milliseconds start = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
	if (ST_OK == (r = stFaceTrackerTrack(faceTrackerHandle, &image, direction, &faceArray, &faceCount)) && faceCount > 0) {
			std::chrono::milliseconds end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
		faceSUM += (end - start);
		cout << "track success." << endl;
		cout << "face count:" << faceCount << endl;

		STFace* s = faceArray;

		for (int i = 0; i < faceCount; i++) {
			cout << "face no.:" << i << " id:" << (s + i)->id << endl;
			cout << "face no.:" << i << " score:" << (s + i)->score << endl;
			cout << "face no.:" << i << " label:" << (s + i)->label << endl;
			cout << "face no.:" << i << " orientation:" << (s + i)->orientation << endl;
			cout << "face no.:" << i << " yaw:" << (s + i)->yaw << endl;
			cout << "face no.:" << i << " pitch:" << (s + i)->pitch << endl;
			cout << "face no.:" << i << " roll:" << (s + i)->roll << endl;
			cout << "face no.:" << i << " rect:{" << endl;
			cout << "	top:" << (s + i)->rect.top << endl;
			cout << "	bottom:" << (s + i)->rect.bottom << endl;
			cout << "	left:" << (s + i)->rect.left << endl;
			cout << "	right:" << (s + i)->rect.right << endl;
			cout << "}" << endl;
			cout << "106points:" << endl;
			cout << "no1 point(x,y):" << (s + i)->points[0].x << ":" << (s + i)->points[0].y << endl;
			cout << "no106 point(x,y):" << (s + i)->points[105].x <<":"<< (s + i)->points[105].y << endl;
		}


	}
	else {
		cout << "track failed. err code:" << r << endl;
		return r;
	}
	return ST_OK;
}

STResult createHandle() {
	STResult r = ST_OK;

	if (ST_OK != (r = stAlignCreate(stmodelalig, &aligHandle))) {
		cout << "create align failed. err code:" << r << endl;
		return r;
	}
	if (ST_OK != (r = stFaceAttributeCreate(stmodelattr, &attrHandle))) {
		cout << "create attribute failed. err code:" << r << endl;
		return r;
	}
	if (ST_OK != (r = stFeatureExtractCreate(stmodelfeature, &extractHandle))) {
		cout << "create featureExtract failed. err code:" << r << endl;
		return r;
	}
	if (ST_OK != (r = stFeatureComparatorCreate(stmodelfeature, &compareHandle))) {
		cout << "create feature comparator handle failed. err code:" << r << endl;
		return r;
	}

	if (ST_OK != (r = stFaceLivenessCreate(stmodellive, &liveHandle))) {
		cout << "create live handle failed. err code:" << r << endl;
		return r;
	}

	return ST_OK;
}

STResult imageCrop() {
	STResult r = ST_OK;
	float quality;
	if (ST_OK != (r = stImageQuality(&image, faceArray, aligHandle, &quality))) {
		cout << "get image quality failed. err code:" << r << endl;
		return r;
	}
	cout << "quality:" << quality << endl;


	STImage* outImage;
	if (ST_OK != (r = stImageCrop(&image, faceArray, aligHandle, &outImage))) {
		cout << "crop image failed. err code:" << r << endl;
		return r;
	}
	cout << "crop image:" << endl;
	cout << "format:" << outImage->format << endl;
	cout << "width:" << outImage->width << endl;
	cout << "height:" << outImage->height << endl;
	cout << "stride:" << outImage->stride << endl;


	cv::Mat mat(outImage->height, outImage->width, CV_8UC3, outImage->data);
	if (!cv::imwrite(outImageFile, mat)) {
		cout << "imwrite crop image failed." << endl;
	}

	stImageRelease(outImage);

	return r;
}

STResult attributeDetect() {
	STResult r = ST_OK;


	STFace* faces = faceArray;
	for (int i = 0; i < faceCount; ++i) {
		STAttribute attr;
		std::chrono::milliseconds start = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
		if (ST_OK != (r = stFaceAttributeDetect(&image, faces + i, attrHandle, aligHandle, &attr))) {
			cout << "attribute detect failed. err code:" << r << endl;
			return r;
		}
		std::chrono::milliseconds end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
		attrSUM += end - start;
		cout << "no." << i << " :attribute:" << endl;
		cout << "age:" << attr.age << endl;
		cout << "attractive:" << attr.attractive << endl;
		cout << "smile:" << attr.smile << endl;
		cout << "gender:" << attr.gender << endl;
		cout << "mask:" << attr.mask << endl;
		cout << "glass:" << attr.glass << endl;
		cout << "baby:" << attr.baby << endl;
		cout << "babycry:" << attr.babycry << endl;
		cout << "race:" << attr.race << endl;
		cout << "emotion:" << attr.emotion << endl;
		cout << "beard:" << attr.beard << endl;
		cout << "eye:" << attr.eye << endl;
		cout << "mouth:" << attr.mouth << endl;
	}
	return ST_OK;
}

STResult extfeature(const STImage* image, const STFace* face, STFeature* feature) {
	STResult r;


	if (ST_OK != (r = stFeatureExtract(image, face, extractHandle, aligHandle, feature))) {
		cout << "extract feature failed. err code:" << r << endl;
		return r;
	}

	return ST_OK;
}

STResult featureCompare() {
	STResult r = ST_OK;
	STImage image1;
	cv::Mat srcImage1;
	getImage(srcImageFile1, srcImage1, &image1);
	STImage image2;
	cv::Mat srcImage2;
	getImage(srcImageFile2, srcImage2, &image2);
	STFace* face1;
	int fcount1 = 0;
	STFace* face2;
	int fcount2 = 0;
	for (int i = 0; i < times; ++i) {
		stFaceTrackerTrack(faceTrackerHandle, &image1, ST_FACE_UP, &face1, &fcount1);	
		usleep(30);
	}
	for (int i = 0; i < times; ++i) {
		stFaceTrackerTrack(faceTrackerHandle, &image2, ST_FACE_UP, &face2, &fcount2);
		usleep(30);
	}
	if (fcount1 < 1 || fcount2 < 1) {
		cout << "no face tracked." << endl;
		return -100;
	}

	STFeature feature1;
	std::chrono::milliseconds start = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
	if (ST_OK != (r = extfeature(&image1, face1, &feature1))) {
		cout << "extract feature1 failed.err code:" << r << endl;
		return r;
	}
	std::chrono::milliseconds end = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch());
	featureSUM += end - start;
	STFeature feature2;
	if (ST_OK != (r = extfeature(&image2, face2, &feature2))) {
		cout << "extract feature2 failed.err code:" << r << endl;
		return r;
	}

	float score = 0;
	if (ST_OK != (r = stFeatureCompare(compareHandle, feature1, feature2, &score))) {
		cout << "feature comparator failed. err code:" << r << endl;
		return r;
	}
	cout << "score:" << score << endl;

	stFeatureExtractResultRelease(feature1);
	stFeatureExtractResultRelease(feature2);

	return ST_OK;

}

int main() {


	if (ST_OK != activation()) {
		cout << "license check failed." << endl;
		return -1;
	}
	if (ST_OK != loadFaceModel()) {
		cout << "load facemodel failed." << endl;
		return -1;
	}
	cout << "load face model success." << endl;
	if (ST_OK != loadModel()) {
		cout << "load common model failed." << endl;
		return -1;
	}
	cout << "load common model success." << endl;
	if (ST_OK != createHandle()) {
		cout << "create Handle failed." << endl;
		return -1;
	}
	cout << "----------------------------------------" << endl;

	if (flag) {
		video();
	}else {

		getImage(srcImageFile);


		if (ST_OK != faceTracker()) {
			cout << "face tracker failed." << endl;
			return -1;
		}
		if (faceCount < 1) {
			cout << "no face detect ." << endl;
			return -1;
		}
		cout << "face tracker success." << endl;
		if (ST_OK != imageCrop()) {
			cout << "image crop failed." << endl;
		}
		else {
			cout << "image crop success" << endl;
		}
		if (ST_OK != attributeDetect()) {
			cout << "get attribute failed." << endl;
		}
		else {
			cout << "get attribute success" << endl;
		}
		if (ST_OK != featureCompare()) {
			cout << "ext feature failed." << endl;
		}
		else {
			cout << "ext feature success." << endl;
		}
	}

	cout << "----------------------------------------" << endl;

	stFeatureComparatorDestroy(compareHandle);
	stFeatureExtractDestroy(extractHandle);
	stFaceAttributeDestroy(attrHandle);
	stFaceTrackerDestroy(faceTrackerHandle);
	stAlignDestroy(aligHandle);
	stFaceLivenessDestroy(liveHandle);

	unloadModel();

	cout << "test finished." << endl;
	return 0;

}
