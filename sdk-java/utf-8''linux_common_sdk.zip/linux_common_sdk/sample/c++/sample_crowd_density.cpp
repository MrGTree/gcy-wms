#include "sensight_crowd_density.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <opencv2/opencv.hpp>
#include "sensight_license.h"

using namespace std;

static string licensePath = "../models/license.lic";
static const char * crowdDensityModel="../models/M_Crowd_Keypoint_1.0.0.model";

STBuffer licenseBuffer = {0};
STBuffer* codeBuffer = nullptr;

static STResult activation() {


	ifstream is(licensePath, ios::binary | ios::ate);
	if (!is) {
		cout << "open license failed." << endl;
		return -100;
	}

	licenseBuffer.size = is.tellg();
	licenseBuffer.data = malloc(licenseBuffer.size);
	is.seekg(0, ios::beg);
	is.read((char*)licenseBuffer.data, licenseBuffer.size);
	is.close();

	STResult r = ST_OK;

	if (ST_OK != (r = stGenerateActivationCode(&licenseBuffer, &codeBuffer))) {
		cout << "generateActivationCode failed.err code:" << r << endl;
	}
	else if (ST_OK != (r = stCheckActivationCode(&licenseBuffer, codeBuffer))) {
		cout << "checkActivationCode failed.err code:" << r << endl;
	}

	free(licenseBuffer.data);

	return r;
}

static cv::Mat visualize_dmap(const cv::Mat& ori_img,
                       const STCrowdDensityResult* crowd_result) {
    cv::Mat dmap(crowd_result->height, crowd_result->width, CV_32FC1,
                 crowd_result->densityMap);
    // normalize dmap
    double minVal, maxVal;
    int minIdx[2] = {}, maxIdx[2] = {};
    minMaxIdx(dmap, &minVal, &maxVal, minIdx, maxIdx);
    dmap = dmap / maxVal;
    dmap.convertTo(dmap, CV_8UC3, 255);
    // gen color map and resize
    cv::Mat color_dmap;
    applyColorMap(dmap, color_dmap, cv::COLORMAP_JET);
    resize(color_dmap, color_dmap, ori_img.size());
    // add weight for visualize
    cv::Mat vis_dmap, base_img;
    base_img = ori_img.clone();

    float alpha = 0.5;
    addWeighted(color_dmap, alpha, base_img, 1 - alpha, 0, vis_dmap);
    cout << "keypoint count = " << crowd_result->keypointCount << endl;

    // draw keypoint
    for (int i = 0; i < crowd_result->keypointCount; ++i) {
        circle(
            vis_dmap,
            cv::Point(int(crowd_result->keypoints[i].x), int(crowd_result->keypoints[i].y)),
            3,
            cv::Scalar(255, 255, 255),
            -1);
        cv::putText(vis_dmap, to_string(crowd_result->pointsScore[i]),
            cv::Point(int(crowd_result->keypoints[i].x), int(crowd_result->keypoints[i].y - 5)),
                    cv::FONT_HERSHEY_COMPLEX_SMALL, 1, cv::Scalar(255, 0, 0),
                    2, 8, false);
    }
    return vis_dmap;
}

int main(int argc, char** argv){
    if (argc < 2) {
        cout << "Usage: ./sample_crowd_density <image_path>" << endl;
        return -1;
    }

    if (ST_OK != activation()) {
	cout << "license check failed." << endl;
	return -1;
    }

    STResult r=ST_OK;
    const char* srcImgPath = argv[1];

    cv::Mat frame=cv::imread(srcImgPath, cv::IMREAD_COLOR);
    if(frame.empty()){
        cout << "err, read image from file failed..." << endl;
        return -1;
    }

    STHandle crowdDensityHandle = nullptr;
    if(ST_OK!=(r=stCrowdDensityCreate(crowdDensityModel, &crowdDensityHandle))){
        cout<<"crowd density handle create failed. err code : "<<r<<endl;
        return -1;
    }

    STImage image;
    image.data      = frame.data;
    image.format    = ST_PIX_FMT_BGR888;
    image.width     = frame.cols;
    image.height    = frame.rows;
    image.stride    = frame.cols * 3;
    image.reserved1 = 0;
    image.reserved2 = 0;

    STCrowdDensityResult crowdResult = {0};

    r = stCrowdDensityDetect(crowdDensityHandle, &image, &crowdResult);
    if (ST_OK != r) {
        cout << "face detect failed. err code : " << r << endl;
        return -1;
    }

    // visulize the result.
    std::cout << static_cast<int>(crowdResult.numberOfPeople + 0.5F) << " people in picture." << std::endl;
    cv::Mat vis_dmap = visualize_dmap(frame, &crowdResult);

    // release the result.
    stCrowdDensityResultRelease(&crowdResult);

    cv::imshow("test", vis_dmap);
    cv::waitKey(0);
    cout << "press any key to exit..." << endl;
    getchar();

    stCrowdDensityDestroy(crowdDensityHandle);

    return 0;
}

