###使用前需知：
1. 本样本示例使用了opencv4.1版本库。使用前需要安装opencv4.1版本(注意需要打开Java支持）
2. 使用前需要修改模型和license路径。


###tips:
1. 把license文件放到models目录中，重命名为license.lic
2. 在IntelliJ中打开jni_sdk_test, 然后选择菜单File->Project Structure，修改其中的jar包及JNI依赖路径
3. build并运行demo。比如: ./demo test.jpg
4. 如果运行报打不开xxx.so.1.0文件，可以在库文件目录下建个软链接。如: ln -s xxx.so xxx.so.1.0
5. 如果运行中出现unsatisfied link error, 请确认jar包及jni动态库的路径设置正确。
