#ifndef SENSIGHT_HANDUP_H
#define SENSIGHT_HANDUP_H

#include "sensight.h"

ST_API STResult
stHandUpDetectorCreate(
    const char* handupModelPath,
    STHandle* pHandle
);

ST_API STResult
stHandUpDetectorDetect(
    const STHandle handle,
    const STImage* image,
    const STBody *body,
    bool *result
);

ST_API STResult
stHandUpDetectorDestroy(
    STHandle handle
);
#endif //SENSIGHT_HANDUP_H