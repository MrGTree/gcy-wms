#ifndef SENSIGHT_LIVENESS_H
#define SENSIGHT_LIVENESS_H

#include "sensight.h"

ST_API STResult
stFaceLivenessCreate(
    STModel model,
    STHandle* handle
);

ST_API STResult
stFaceLivenessVerify(
    const STImage* image,
    const STFace* face,
    const STHandle liveHandle,
    const STHandle alignHandle,
    float* score
);

ST_API void
stFaceLivenessDestroy(
    STHandle handle
);

#endif  // SENSIGHT_LIVENESS_H