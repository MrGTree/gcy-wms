#ifndef SENSIGHT_SENSIGHT_CROWD_DENSITY_H
#define SENSIGHT_SENSIGHT_CROWD_DENSITY_H

#include "sensight.h"

ST_API STResult
stCrowdDensityCreate(
    const char* crowdDensityModel,
    STHandle* handle
);

ST_API STResult
stCrowdDensityDetect(
    STHandle handle,
    const STImage* image,
    STCrowdDensityResult* result
);

ST_API void
stCrowdDensityResultRelease(
    STCrowdDensityResult* attr
);

ST_API void
stCrowdDensityDestroy(
    STHandle crowdDensityHandle
);

#endif // SENSIGHT_SENSIGHT_CROWD_DENSITY_H
