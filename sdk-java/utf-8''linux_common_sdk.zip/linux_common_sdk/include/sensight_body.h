#ifndef SENSIGHT_BODY_H
#define SENSIGHT_BODY_H

#include "sensight.h"

ST_API STResult stBodyGetKeypointDefinition(
        const char* bodyDetectModel,
        const char* bodyAlignModel,
        STBodyKeypointDefinition *keypointDefinition
);

ST_API STResult
stBodyTrackerCreate(
    const char* bodyDetectModel,
    const char* bodyAlignModel,
    STHandle* bodyTrackerHandle
);

// @param val - key like: CONFIG_BODY_DETECT_THRESHOLD_SCORE
ST_API STResult
stBodyTrackerConfig(
	STHandle handle,
	int key,
	float val
);

ST_API STResult
stBodyTrackerTrack(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STBody** bodyArray,
    int* bodyCount
);

ST_API void
stBodyTrackerReset(STHandle bodyTracker);

ST_API void
stBodyTrackerDestroy(
    STHandle bodyTracker
);

ST_API STResult
stBodyDetectorCreate(
    const char* bodyDetectModel,
    STHandle* bodyDetectorHandle
);

ST_API STResult
stBodyDetectorConfig(
STHandle handle,
int key,
float val
);


ST_API STResult
stBodyDetectorDetect(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STBody** bodyArray,
    int* bodyCount
);

ST_API void
stBodyDetectorDestroy(
    STHandle bodyDetectorHandle
);

#endif //SENSIGHT_BODY_H
