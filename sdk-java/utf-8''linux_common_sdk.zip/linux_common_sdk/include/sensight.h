#ifndef SENSIGHT_H
#define SENSIGHT_H

#ifdef SDK_EXPORTS
#	ifdef _MSC_VER
#		define  ST_API_ __declspec(dllexport)
#	else /*MSC_VER*/
#		define ST_API_ __attribute__((visibility ("default")))
#	endif
#else
#   define ST_API_
#endif

#ifdef __cplusplus
#   define ST_API extern "C" ST_API_
#else
#   define ST_API ST_API_
#endif

const int ST_OK                                 = 0;        ///< 正常运行
const int ST_E_INVALID_ARG                      = -1;       ///< 无效参数
const int ST_E_HANDLE                           = -2;       ///< 句柄错误
const int ST_E_OUT_OF_MEMORY                    = -3;       ///< 内存不足
const int ST_E_FAIL                             = -4;       ///< 内部错误
const int ST_E_UNSUPPORTED                      = -5;       ///< 功能尚未支持
const int ST_E_INVALID_PIXEL_FORMAT             = -6;       ///< 图像格式不支持
const int ST_E_FILE_NOT_EXIST                   = -7;       ///< 文件不存在
const int ST_E_INVALID_FILE_FORMAT              = -8;       ///< 模型格式错误
const int ST_E_INVALID_LICENSE                  = -13;      ///< 授权文件无效
const int ST_E_LICENSE_EXPIRE                   = -15;      ///< 授权文件过期
const int ST_E_INVALID_ACTIVATION_CODE          = -22;      ///< 离线激活码无效
const int ST_E_INVALID_ONLINE_ACTIVATION_CODE   = -29;      ///< 在线激活码无效
const int ST_E_LICENSE_NO_CAPABILITY            = -1001;    ///< license没有授予这项能力
const int ST_E_LICENSE_EXCEED_CONCURRENT_LIMIT  = -1002;    ///< 超过路数限制

typedef void* STModel;
typedef void* STHandle;
typedef int STResult;
typedef char* STFeature;

typedef enum {
    ST_PIX_FMT_GRAY8,       ///< Y    1        8bpp (单通道8bit灰度)
    ST_PIX_FMT_I420,        ///< YUV  4:2:0   12bpp (3通道, 亮度通道, U分量通道, V分量通道. 所有通道都是连续的)
    ST_PIX_FMT_NV12,        ///< YUV  4:2:0   12bpp (2通道, 亮度通道和UV分量交错通道)
    ST_PIX_FMT_NV21,        ///< YUV  4:2:0   12bpp (2通道, 亮度通道和VU分量交错通道)
    ST_PIX_FMT_BGRA8888,    ///< BGRA 8:8:8:8 32bpp (4通道32bit)
    ST_PIX_FMT_BGR888,      ///< BGR  8:8:8   24bpp (3通道24bit)
    ST_PIX_FMT_RGBA8888,    ///< RGBA 8:8:8:8 32bpp (4通道32bit)
    ST_PIX_FMT_RGB888       ///< RGB  8:8:8   24bpp (3通道24bit)
} STPixelFormat;

///
/// 人脸朝向。 包括朝上（不旋转）,朝下（头朝下，图像被旋转180度）,朝左（旋转270度）, 朝右(旋转90度)
///
typedef enum {
    ST_FACE_UNKNOWN,
    ST_FACE_UP,
    ST_FACE_DOWN,
    ST_FACE_LEFT,
    ST_FACE_RIGHT
} STFaceDirection;

typedef struct STPoint {
    float x;
    float y;
} STPoint;

typedef struct STRect {
    int left;
    int top;
    int right;
    int bottom;
} STRect;

typedef struct STImage {
    unsigned char* data;    ///< 图像数据指针
    STPixelFormat format;   ///< 像素格式
    int width;              ///< 图像宽度(像素)
    int height;             ///< 图像高度(像素)
    int stride;             ///< 图像宽度(每行所占的字节数)
    long reserved1;         ///< 保留字段
    long reserved2;         ///< 保留字段
} STImage;

typedef struct STBuffer {
    void* data;
    unsigned int size;
} STBuffer;

typedef struct STFaceBasicInfo {
	STRect rect;            ///< 人脸框
	int label;              ///< 结果标签
	int orientation;        ///< 人脸朝向
	float score;            ///< 人脸框分值
} STFaceBasicInfo;

typedef struct STFace {
    int id;                 ///< 人脸ID
    float score;            ///< 人脸质量分
    STRect rect;            ///< 人脸框
    int label;              ///< 结果标签
    int orientation;        ///< 人脸朝向
    STPoint points[106];    ///< 关键点
    float yaw;              ///< 水平转角, 视频中人头的方向, 左负右正
    float pitch;            ///< 俯仰角, 上负下正
    float roll;             ///< 旋转角, 左负右正
} STFace;

///
/// 人体关键点的定义
/// index为该部位关键点在STBody.points中的位置(从0开始), -1表示不支持这个关键点
///
typedef struct STBodyKeypointDefinition {
    int pointCount;           // 共多少个点
    int foreheadIdx;          // 前额
    int neckIdx;              // 脖子
    int leftShoulderIdx;      // 左肩
    int rightShoulderIdx;     // 右肩
    int leftElbowIdx;         // 左肘
    int rightElbowIdx;        // 右肘
    int leftWristIdx;         // 左腕
    int rightWristIdx;        // 右腕
    int leftHipIdx;           // 左髋
    int rightHipIdx;          // 右髋
    int leftKneeIdx;          // 左膝
    int rightKneeIdx;         // 右膝
    int leftAnkleIdx;         // 左踝
    int rightAnkleIdx;        // 右踝
} STBodyKeypointDefinition;

typedef struct STBody {
    int id;
    float score;            ///< 人体框质量分
    STRect rect;            ///< 人体框
    int points_count;       ///< 有效的关键点个数
    STPoint points[14];     ///< 关键点数组，个数由points_count决定
    float pointsScore[14];  ///< 关键点置信度, <= -1表示该模型不支持关键点置信度
    int label;              ///< 结果标签
    int orientation;        ///< 结果朝向
} STBody;

typedef struct STBodyAttributeItem {
    unsigned char* category;
    unsigned char* label;
} STBodyAttributeItem;

typedef struct STBodyAttribute {
    STBodyAttributeItem* items;
    int count;
    void* opaqueData;
} STBodyAttribute;

typedef enum PersonFlag {
	PERSON_FLAG_HAS_FACE = 0x01,
	PERSON_FLAG_HAS_BODY = 0x02
} PersonFlag;

typedef struct STPerson {
    unsigned int flag;
    STFace face;
    STBody body;
} STPerson;

typedef struct STAttribute {
	enum gender_t {
		GENDER_FEMALE = 0,
		GENDER_MALE,
	};
	enum mask_t {
		NO_MASK= 0,
		HAS_MASK=1,
	};
	enum glass_t {
		NO_GLASS = 0,           ///< 无眼镜 
		GENERAL_GLASS = 1,      ///< 普通眼镜
		SUN_GLASS = 2,          ///< 太阳镜
	};
	enum baby_t {
		NOT_BABY = 0,
		IS_BABY = 1,
	};
	enum babycry_t {
		NOT_CRYING = 0,
		CRYING = 1,
	};
	enum race_t {
		RACE_YELLOW= 0,
		RACE_BLACK= 1,
		RACE_WHITE= 2,
		RACE_UNKNOWN = 255
	};
	enum emotion_t {
		EMOTION_ANGRY = 0,      ///< 愤怒
		EMOTION_CALM = 1,       ///< 平静
		EMOTION_DISGUST = 2,    ///< 厌恶
		EMOTION_HAPPY = 3,      ///< 愉快
		EMOTION_SAD = 4,        ///< 难过
		EMOTION_SCARED = 5,     ///< 恐惧
		EMOTION_SURPRISE = 6,   ///< 吃惊
        EMOTION_UNCLEAR = 7,
        EMOTION_INVALID = 8
	};
	enum beard_t {
		NO_BEARD = 0,
		HAS_BEARD = 1,
	};
	enum eye_t {
		EYE_OPEN = 0,
		EYE_CLOSE = 1,
	};
	enum mouth_t {
		MOUTH_OPEN = 0,
		MOUTH_CLOSE = 1,
	};
	gender_t gender;
	mask_t mask;
	glass_t glass;
	baby_t baby;
	babycry_t babycry;
	race_t race;
	emotion_t emotion;
	beard_t beard;
	eye_t eye;
	mouth_t mouth;
	float age;              ///< 年龄
	float attractive;       ///< 魅力值[0-100]
	float smile;            ///< 微笑程度[0-100]
    int au1;
    int au2;
    int au3;
    int au4;
    int au5;
}STAttribute;


// the config macros
enum ConfigKey {
    CONFIG_BODY_DETECT_THRESHOLD_SCORE = 0x01,
    CONFIG_BODY_TRACK_MAX_COUNT = 0x02
};

///
/// @brief 人群密度检测的结果，需要调用stCrowdDensityResultRelease()释放
///
typedef struct STCrowdDensityResult {
    int numberOfPeople;
    int width;
    int height;
    float* densityMap;
    int keypointCount;
    STPoint* keypoints;
    float* pointsScore;         /// 置信度
} STCrowdDensityResult;

/*
ST_API int stImageConvert();
ST_API int stImageResize();
ST_API int stImageRotate();
*/
#endif  // SENSIGHT_H
