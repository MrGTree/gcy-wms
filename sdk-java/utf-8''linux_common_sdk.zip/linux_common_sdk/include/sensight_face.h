#ifndef SENSIGHT_FACE_H
#define SENSIGHT_FACE_H

#include "sensight.h"

ST_API STResult
stFaceTrackerCreate(
    const char* faceDetectModel,
    const char* faceAlignModel,
    const char* headPoseModel,
    STHandle* faceTrackerHandle
);

ST_API STResult
stFaceTrackerTrack(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STFace** faceArray,
    int* faceCount
);

/**
 * Detect the face in image synchronously.
 */
ST_API STResult
stFaceTrackerDetect(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STFace** faceArray,
    int* faceCount
);

/**
 * Detect the face basic info in image synchronously.
 * @param handle The handle created from stFaceTrackerCreate().
 * @param image The static image to be detected.
 * @param direction The face direction.
 * @param basicInfoArray The face basic info detected from the image.
 * @param faceCount The count of faces
 * @return ST_OK success, otherwise fail.
 */
ST_API STResult
stFaceTrackerDetectBasicInfo(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STFaceBasicInfo** basicInfoArray,
    int* faceCount
);

ST_API STResult
stFaceTrackerGetDetailedInfo(
    STHandle handle,
    const STImage* image,
    const STFaceBasicInfo* basic,
    STFace* details
);


ST_API void
stFaceTrackerDestroy(
    STHandle faceTracker
);

#endif
