#ifndef SENSIGHT_WRAPPER_H
#define SENSIGHT_WRAPPER_H

#include "sensight.h"
#include <cv_common.h>
#include <cv_matrix_internal.h>

ST_API int
st_protector_get_online_activation_code(const char *license_string, int time_expire, char **signed_code);

ST_API void
st_protector_release_activate_code(char *signed_code);

ST_API int
st_protector_add_license(const char *license_string, const char *signed_code);

ST_API int
st_common_load_model(const char *file, cv_model_t *model);

ST_API void
st_common_unload_model(cv_model_t model);

CV_SDK_API void
st_common_model_name(cv_model_t m, char name[CV_COMMON_MAX_TEXT_LENGTH]);

ST_API int
st_common_detection_hunter_create(cv_model_t model, cv_handle_t *p_hunter_handle);

ST_API int
st_common_detection_hunter_detect(cv_handle_t handle, const cv_image_t *image, cv_detection_result_t **result, int *count);

ST_API int
st_common_detection_hunter_get_threshold(cv_handle_t handle, float *threshold);

ST_API void
st_common_detection_hunter_release_result(cv_detection_result_t *result, int count);

ST_API void
st_common_detection_hunter_destroy(cv_handle_t handle);

ST_API int
st_common_alignment_deep_create(cv_model_t model, cv_handle_t *handle);

ST_API int
st_common_alignment_align_by_rect(cv_handle_t align_handle, const cv_image_t *p_image, const cv_rect_t *rects, int count, int rotate_degree, cv_landmarks_t **landmarks);

ST_API int
st_common_alignment_align_by_pose(cv_handle_t handle, const cv_image_t *p_image, const cv_landmarks_t *landmarks_in, int count, cv_landmarks_t **landmarks_out);

ST_API void
st_common_alignment_release_result(cv_landmarks_t *landmarks, int count);

ST_API void
st_common_alignment_destroy(cv_handle_t handle);

ST_API int
st_face_calcpose_cnn_create(cv_model_t model, cv_handle_t *handle);

ST_API int
st_face_calcpose_get_pose(cv_handle_t handle, const cv_pointf_t *points_array, int points_count, cv_pose_t* pose);

ST_API void
st_face_calcpose_destroy(cv_handle_t handle);

ST_API int
st_common_tracking_compact_create(cv_model_t model, cv_handle_t detector, unsigned int config, cv_handle_t* p_handle);

ST_API int
st_common_tracking_compact_config(cv_handle_t handle, unsigned int config, int val, int* new_val);

ST_API int
st_common_tracking_compact_track(cv_handle_t handle, const cv_image_t* p_image, cv_orientation orientation, cv_target_t **p_targets_array, int *p_targets_count);

ST_API void
st_common_tracking_compact_release_result(cv_target_t *target_array, int target_count);

ST_API void
st_common_tracking_compact_destroy(cv_handle_t handle);

ST_API int
st_face_utils_eye_distance(const cv_pointf_t *points21, int points_count, float* eye_dist);

ST_API int
st_matrix_face_attribute_create(cv_model_t model, cv_handle_t *handle);

ST_API int
st_matrix_face_attribute_classify (cv_handle_t handle, const cv_image_t *image, const cv_landmarks_t* lms, int face_count, cv_face_attribute_result_list_t **result);

ST_API void
st_matrix_release_attribute_result_list(cv_face_attribute_result_list_t *result);

ST_API void
st_matrix_face_attribute_destroy(cv_handle_t handle);

ST_API int
st_common_feature_extractor_create(cv_model_t model, cv_handle_t* handle);

ST_API int
st_common_feature_comparator_create(cv_model_t model, cv_handle_t* handle);

ST_API int
st_common_feature_extractor_extract(cv_handle_t handle, const cv_image_t *image, int encrypted, cv_feature_t** feature);

ST_API int
st_common_feature_comparator_normalize(cv_feature_t *feature);

ST_API int
st_common_feature_comparator_get_distance(const cv_feature_t* feature1, const cv_feature_t* feature2, float* score);

ST_API int
st_common_feature_comparator_normalize_score_by_model(cv_handle_t handle, float original_score, float *normalized_score);

ST_API void
st_common_feature_extractor_destroy(cv_handle_t handle);

ST_API void
st_common_feature_comparator_destroy(cv_handle_t handle);

ST_API int
st_feature_serialize(const cv_feature_t *feature, char *feature_str);

ST_API cv_feature_t*
st_feature_deserialize(const char *feature_str);

ST_API int
st_common_feature_release(cv_feature_t *feature);

ST_API int
st_matrix_sight_gaze_create(cv_model_t model, cv_handle_t *handle);

ST_API int
st_matrix_sight_gaze_get_result(cv_handle_t handle, const cv_image_t *image, const cv_landmarks_t *lms, float *gaze_score, int *result);

ST_API void
st_matrix_sight_gaze_destroy(cv_handle_t handle);

ST_API int
st_image_allocate(int width, int height, cv_pixel_format pixel_format, cv_image_t ** image);

ST_API void
st_image_release(cv_image_t* image);

ST_API int
st_common_image_rotate(const cv_image_t *image_src, cv_image_t *image_dst, unsigned int rotate_degree);

ST_API int
st_common_color_convert(const cv_image_t* image_src, cv_image_t* image_dst);

ST_API int
st_common_crop_face_by_points(const cv_image_t *in, const cv_pointf_t *points, int points_count, cv_image_t **out, int mode);

ST_API int
st_common_get_quality(const cv_image_t* image, const cv_pose_t* pose, const cv_detection_result_t* detection_r, const cv_landmarks_t* landmark_r, float* quality);

#endif //SENSIGHT_WRAPPER_H
