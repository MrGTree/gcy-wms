###使用前需知：
1. 本样本示例使用了opencv4.1版本库，以及c++11特性。使用前需要安装opencv4.1版本
2. 使用前需要修改模型和license路径，修改原始图像路径。


###tips:
1. 把license文件放到models目录中，重命名为license.lic
2. 编译参考命令：  g++ sample_crowd_density.cpp -o demo -std=c++11 $(pkg-config --libs --cflags opencv4) -I 头文件路径 -L 库文件路径 -l stad_common（库文件名）
您可以直接在sample目录中运行./build.sh
3. 配置环境：export LD_LIBRARY_PATH=../libs
4. 运行demo: 比如: ./demo test.jpg
5. 如果运行报打不开xxx.so.1.0文件，可以在库文件目录下建个软链接。如: ln -s xxx.so xxx.so.1.0
