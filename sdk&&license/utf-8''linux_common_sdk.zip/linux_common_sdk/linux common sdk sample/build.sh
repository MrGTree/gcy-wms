g++ sample_crowd_density.cpp -o demo -std=c++11 $(pkg-config --libs --cflags opencv4) -I ../include -L ../libs -l stad_common
