#ifndef SENSIGHT_COMMON_H
#define SENSIGHT_COMMON_H

#include "sensight.h"

ST_API STResult
stCommonLoadModel(const char* modelPath, STModel* model);

ST_API void
stCommonUnloadModel(STModel model);

#endif //SENSIGHT_COMMON_H