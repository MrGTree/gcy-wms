#ifndef SENSIGHT_LOGO_H
#define SENSIGHT_LOGO_H

#include "sensight.h"

typedef struct STLogo {
    int label;      /// logo标识
    float score;    /// logo检测置信度
    STRect rect;    /// logo位置
} STLogo;

ST_API STResult
stLogoGetActivationCode(
    const char* license,
    char** activationCode
);

ST_API void
stLogoReleaseActivationCode(
    char* activationCode
);

ST_API STResult
stLogoAddLicense(
    const char* license,
    const char* activationCode
);

ST_API STResult
stLogoDetectorCreate(
    const char* modelPath,
    STHandle* handle
);

ST_API STResult
stLogoDetectorDetect(
    STHandle handle,
    STImage* image,
    STLogo** logos,
    int* count
);

ST_API void
stLogoDetectorReleaseResults(
    STLogo* logos
);

ST_API void
stLogoDetectorDestroy(
    STHandle handle
);

#endif  // SENSIGHT_LOGO_H
