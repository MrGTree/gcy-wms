#ifndef SENSIGHT_ATTRIBUTE_H
#define SENSIGHT_ATTRIBUTE_H

#include "sensight.h"

ST_API STResult
stFaceAttributeCreate(
    STModel model,
    STHandle* handle
);

ST_API STResult
stFaceAttributeCreateEx(STModel attrModel, STModel emotionModel, STHandle* handle);

ST_API STResult
stFaceAttributeDetect(
    const STImage* image,
    const STFace* face,
    const STHandle attrHandle,
    const STHandle alignHandle,
    STAttribute* attribute
);

ST_API void
stFaceAttributeDestroy(
    STHandle handle
);

ST_API STResult
stBodyAttributeCreate(
    STModel model,
    STHandle* handle
);

ST_API STResult
stBodyAttributeDetect(
    const STHandle attrHandle,
    const STImage* image,
    const STBody* body,
    STBodyAttribute* attribute
);

ST_API void
stBodyAttributeResultRelease(
    STBodyAttribute* attr
);

ST_API void
stBodyAttributeDestroy(
    STHandle handle
);
#endif  // SENSIGHT_ATTRIBUTE_H
