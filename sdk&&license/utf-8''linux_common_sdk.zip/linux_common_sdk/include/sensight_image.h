#ifndef SENSIGHT_IMAGE_H
#define SENSIGHT_IMAGE_H

#include "sensight.h"

ST_API STResult
stImageQuality(const STImage* image, const STFace* face,
               const STHandle alignHandle, float* quality);

ST_API STResult
stImageCrop(const STImage* inputImg, const STFace* face,
                   const STHandle alignHandle, STImage** outputImg);

ST_API void
stImageRelease(STImage* image);

#endif //SENSIGHT_IMAGE_H