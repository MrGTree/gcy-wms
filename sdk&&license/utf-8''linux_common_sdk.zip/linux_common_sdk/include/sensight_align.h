#ifndef SENSIGHT_ALIGN_H
#define SENSIGHT_ALIGN_H

#include "sensight.h"

ST_API STResult
stAlignCreate(STModel model, STHandle* handle);

ST_API void
stAlignDestroy(STHandle handle);

#endif //SENSIGHT_ALIGN_H