#ifndef SENSIGHT_ENCRYPT_H
#define SENSIGHT_ENCRYPT_H

#include "sensight.h"

ST_API STResult
stEncryptorCreate(STHandle* handle);

ST_API STResult
stEncryptorInit(
    STHandle handle,
    const char* N,
    const char* E,
    const char* P,
    const char* D,
    const char* Q
);

ST_API STResult
stEncryptorEncrypt(
    STHandle handle,
    const unsigned char *srcData,
    int srcSize,
    unsigned char **dstData,
    int *dstSize
);

ST_API STResult
stEncryptorDecrypt(
    STHandle handle,
    const unsigned char*srcData,
    int srcSize,
    unsigned char** dstData,
    int* dstSize
);

ST_API void
stEncryptorReleaseData(
    unsigned char* data
);

ST_API void
stEncryptorDestroy(
    STHandle handle
);

#endif  // SENSIGHT_ENCRYPT_H
