#ifndef SENSIGHT_SENSIGHT_PERSON_H
#define SENSIGHT_SENSIGHT_PERSON_H

#include "sensight.h"

/// 关联人脸和人体。目前只返回同时有人脸和人体的person.
/// 注意本关联算法未来可能改变，使用时请注意检查STPerson中的flag（PERSON_FLAG_HAS_FACE / PERSON_FLAG_HAS_FACE）等
/// @param faceArray 待关联的人脸数组
/// @param faceCount 人脸数组个数
/// @param bodyArray 待关联的人体数组
/// @param bodyCount 人体数组个数
/// @param personArrayCapacity personArray数组的容量
/// @param personArray 关联结果数组，由调用者负责分配。返回关联后的person。
/// @param personCount 返回匹配后personArray中的person个数
/// @return ST_OK 成功，其它失败
///
ST_API STResult
stPersonMatchFaceBody(
    const STFace* faceArray,
    int faceCount,
    const STBody* bodyArray,
    int bodyCount,
    int personArrayCapacity,
    STPerson* personArray,
    int* personCount
);

ST_API STResult
stPersonTrackerCreate(
    const char* faceDetectModel,
    const char* faceAlignModel,
	const char* faceHeadposeModel,
	const char* bodyDetectModel,
	const char* bodyAlignModel,
    STHandle* personTrackerHandle
);

// key - CONFIG_BODY_DETECT_THRESHOLD_SCORE
ST_API STResult
stPersonTrackerConfig(
	STHandle handle,
	int key,
	float val
);

ST_API STResult
stPersonTrackerTrack(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STPerson** personArray,
    int* personCount
);

ST_API void
stPersonTrackerDestroy(
    STHandle personTrackerHadle
);

ST_API STResult
stPersonDetectorCreate(
	const char* faceDetectModel,
	const char* faceAlignModel,
	const char* faceHeadposeModel,
	const char* bodyDetectModel,
    STHandle* personDetectorHandle
);

ST_API STResult
stPersonDetectorConfig(
	STHandle handle,
	int key,
	float val
);

ST_API STResult
stPersonDetectorDetect(
    STHandle handle,
    const STImage* image,
    STFaceDirection direction,
    STPerson** personArray,
    int* personCount
);

ST_API void
stPersonDetectorDestroy(
    STHandle personDetectorHandle
);

#endif //SENSIGHT_SENSIGHT_PERSON_H
