#ifndef SENSIGHT_FEATURE_H
#define SENSIGHT_FEATURE_H

#include "sensight.h"

ST_API STResult
stFeatureExtractCreate(STModel model, STHandle* handle);

ST_API STResult
stFeatureExtract(
    const STImage* image,
    const STFace* face,
    const STHandle extractHandle,
    const STHandle alignHandle,
    STFeature* feature
);

ST_API void
stFeatureExtractResultRelease(STFeature feature);

ST_API void
stFeatureExtractDestroy(STHandle handle);

ST_API STResult
stFeatureComparatorCreate(STModel model, STHandle* handle);

ST_API STResult
stFeatureCompare(
    const STHandle comparatorHandle,
    STFeature feature1,
    STFeature feature2,
    float* score
);

ST_API void
stFeatureComparatorDestroy(STHandle handle);
#endif //SENSIGHT_FEATURE_H