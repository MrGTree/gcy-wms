#ifndef SENSIGHT_LICENSE_H
#define SENSIGHT_LICENSE_H

#include "sensight.h"

ST_API STResult
stGenerateActivationCode(
    const STBuffer* licenseBuffer,
    STBuffer** codeBuffer
);

ST_API STResult
stCheckActivationCode(
    const STBuffer* licenseBuffer,
    const STBuffer* codeBuffer
);

ST_API void
stReleaseActivationCode(
    STBuffer* codeBuffer
);

#endif  // SENSIGHT_LICENSE_H