#ifndef SENSIGHT_GAZE_H
#define SENSIGHT_GAZE_H

#include "sensight.h"

ST_API STResult
stGazeDetectorCreate(
    const char* modelPath,
    STHandle* handle
);

ST_API STResult
stGazeDetectorCreateFromBuffer(
    const char* modelBuffer,
    int bufferSize,
    STHandle* handle
);

ST_API STResult
stGazeDetectorDetect(
    STHandle gazeHandle,
    STHandle alignHandle,
    const STImage* image,
    const STRect* faceRect,
    int* gaze
);

ST_API void
stGazeDetectorDestroy(
    STHandle handle
);

#endif  // SENSIGHT_GAZE_H
